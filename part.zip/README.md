# Graph Partitioning for large graphs

Requires graphviz  
```shell
sudo apt install graphviz graphviz-dev
```

To install networkx-metis  
```shell
git clone https://github.com/networkx/networkx-metis.git  
cd networkx-metis  
python setup.py install  
```
