# Graphs characteristics
Information of the graphs in "The Graph Partitioning archive" 
used to test the algorithms and showed in the following format:  
Name - Number of nodes - Number of edges

- Small graphs (~ 10,000 nodes):

add20 - 2395 - 7462  
data - 2851 - 15093  
3elt - 4720 - 13722  
uk - 4824 - 6837  
add32 - 4960 - 9462  
bcsstk33 - 8738 - 291583  
whitaker3 - 9800 - 28989  
crack - 10240 - 30380  

- Medium graphs (~ 50,000 nodes):

fe_body - 45087 - 163734  
t60k - 60005 - 89440  
wing - 62032 - 121544  
finan512 - 74752 - 261120  

- Large graphs (~100,000 nodes):

fe_rotor - 99617 - 662431  
598a - 110971 - 741934  
m14b - 214765 - 1679018	 
auto - 448695 - 3314611  
	