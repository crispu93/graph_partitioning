import torch
from graph_utils import load_graph_file, to_zero_based
import networkx as nx
print(torch.cuda.is_available())

# adj_list = [[1], [0, 2], [1,3], [2]]
# idx_list1 = [x for x, a in enumerate(adj_list) for _ in range(len(a))]
# idx_list2 = [x for a in adj_list for x in a]
# print(idx_list1)
# print(idx_list2)

from graph_utils import load_edge_list_file
file_name = "test_small_graph"

adj_list = load_edge_list_file(file_name)
adj_list = to_zero_based(adj_list)

print(adj_list)
# file_name = "small_graphs/add20"
# adj_list = load_graph_file(file_name)
# adj_list = to_zero_based(adj_list)
# G = nx.from_dict_of_lists(adj_list)

# print(list(map(list, iter(G.adj.values()))))
# for node, adjacencies in enumerate(G.adj()):
#     print(node, adjacencies)